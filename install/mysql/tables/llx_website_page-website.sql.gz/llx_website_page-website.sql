-- ========================================================================
-- Copyright (C) 2016	Laurent Destailleur	<eldy@users.sourceforge.net>
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program. If not, see <https://www.gnu.org/licenses/>.
--
-- ========================================================================


CREATE TABLE llx_website_page
(
	rowid         integer AUTO_INCREMENT NOT NULL PRIMARY KEY,
	fk_website    integer NOT NULL,
	type_container varchar(16) NOT NULL DEFAULT 'page',
	pageurl       varchar(255) NOT NULL,
	aliasalt      varchar(255),
	title         varchar(255),						
	description   varchar(255),						
	image         varchar(255),						
	keywords      varchar(255),
	lang          varchar(6),
	fk_page       integer,
	allowed_in_frames  integer DEFAULT 0,
	htmlheader	  text,
	content		  mediumtext,		-- text is not enough in size
    status        integer DEFAULT 1,
	grabbed_from  varchar(255),
    fk_user_creat integer,
    fk_user_modif integer,
    author_alias  varchar(64),
    date_creation datetime,
	tms           timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    import_key    varchar(14),      -- import key
    object_type   varchar(255),		-- To link page to an object
    fk_object     varchar(255)		-- To link page to an object
) ENGINE=innodb;
